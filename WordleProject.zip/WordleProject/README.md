# Projecte Wordle
Fet per estudiants de AWS2:
- Raúl García
- Brahian Monsalve
- Andrés Villcaa
