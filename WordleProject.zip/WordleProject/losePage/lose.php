<?php session_start(); ?>
<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lose Page</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <main>
        <div id="idTextLose">
            <h1><?php echo strtoupper($_SESSION['user']); ?> NO HAS ENCERTAT LA PARAULA OCULTA!</h1>
            <h1>DERROTA AMB <?php echo $_SESSION['pointsUser']; ?> PUNTS!!</h1>
            <p id="pSeeOcultWord">La paraula a endevinar era <b id="bWordResult"> <?php echo $_SESSION["ocultWord"]; ?></b></h2>
        </div>
        <div id="idLoseGif">
            <img class="imgLose" src="../resources/gifLose.gif" alt="GIF DERROTA" height="225" width="300">
        </div>
        <div id="statistics">
            <div id="statisticsLose">
                <p>Partides fallides: <?php echo $_SESSION['loseGames'];?></p>
            </div>
            <div id="statisticsWin">
                <p>Partides exitoses: <?php echo $_SESSION['winGames'];?></p>
            </div>
        </div>
    </main>
</body>
</html>