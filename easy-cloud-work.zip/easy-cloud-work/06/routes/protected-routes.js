const express = require('express')
const auth = require('../auth/auth')
const multer = require("multer");
const File = require('../model/modelFile')

const multerStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./uploads");
  },
  filename: (req, file, cb) => {
    const extension = file.mimetype.split("/")[1];
    cb(null, `${file.fieldname}-${Date.now()}.${extension}`);
  },
});

const upload = multer({ storage: multerStorage });

const router = express.Router();

router.use(auth.authenticateToken);

router.post("/user", async (req, res) => {

  let filesUser = [];
  for (let i = 0; i < req.user.files.length; i++) {
    let exist = await File.findById(req.user.files[i])
    if (exist) {
      filesUser.push(exist.filename);
    }
  }

  res.render('temp.ejs', {
    user: {
      email: req.user.email,
      files: filesUser
    }
  })
})

router.post("/upload", upload.single('file'), async (req, res, next) => {

  // POST /upload
  // archivo name=file
  // optional isPublic

  isPrivate = false;
  if (req.body.isPublic !== undefined) {
    isPrivate = true
  }

  try {
    const newFile = await File.create({ filename: req.file.filename, isPrivate: isPrivate });
    req.user.files.push(newFile);
    req.user.save();
    res.statusCode = 204;
    next();
  }
  catch (error) {
    return next(error);
  }
})

module.exports = router