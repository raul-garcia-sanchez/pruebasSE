const express = require('express')
const auth = require('../auth/auth')
const router = express.Router();
router.use(auth.loginMiddleware);

const mockUser = {
    "email": "rkernock0@europa.eu",
    "files": [
    "MorbiPorttitor.jpeg",
    "MorbiUt.avi",
    "MagnisDis.xls",
    "Luctus.jpeg",
    "LuctusNec.mp3",
    "EtCommodo.avi",
    "UltricesLibero.avi"
    ]
}

router.get("/user", (req, res) => {
    res.render('temp.ejs', {
      user: {
        email: req.body.email,
        files: mockUser.files
      }
    })
  })
  
module.exports = router