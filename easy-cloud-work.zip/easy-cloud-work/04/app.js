const express = require('express')
const bodyParser = require('body-parser')
const mongoose = require('mongoose')
const routes = require('./routes/routes.js');
const routesProtected = require('./routes/protected-routes.js');

mongoose.connect("mongodb://localhost:27017/usuarios");
const port = 3000

const app = express()

app.set('view engine', 'ejs')

app.use(bodyParser.json());

app.use(function (req, res, next) {
  console.log(req.originalUrl);
  console.log(req.body);
  next();
})

app.use('/', routes)
app.use('/', routesProtected)

app.get('/login', (req, res) => {
  res.sendFile(__dirname + '/login.html');
})

app.get('/signup', (req, res) => {
  res.sendFile(__dirname + '/signup.html');
})

app.use(function (req, res, next) {
  res.statusCode = 501;
  res.end();
})

app.use((err, req, res, next) => {
  res.status(500).send(err.stack)
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})