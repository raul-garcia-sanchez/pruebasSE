const express = require('express')
const auth = require('../auth/auth')
const multer = require("multer");
const File = require('../model/modelFile');

const multerStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./uploads");
  },
  filename: (req, file, cb) => {
    const extension = file.mimetype.split("/")[1];
    cb(null, `${file.fieldname}-${Date.now()}.${extension}`);
  },
});


const upload = multer({ storage: multerStorage });

const router = express.Router();


router.use(auth.authenticateToken);
router.use(auth.refreshToken);

router.post("/upload", upload.single('file'), async (req, res, next) => {
  try {
    if (req.body.description.length > 0){
      var newFile = await File.create({ filename: req.file.filename, name: req.body.name, description: req.body.description, isPrivate: req.body.isPrivate });
    }
    else{
      var newFile = await File.create({ filename: req.file.filename, name: req.body.name, isPrivate: req.body.isPrivate });
    }
    req.user.files.push(newFile);
    req.user.save();
    res.statusCode = 204;
    res.end();
  }
  catch (error) {
    res.statusCode = 404;
    next(error);
  }
});

router.get("/download:id", async (req, res, next) =>{
  let idFile = req.params.id.substring(1);
  if (idFile.length > 24){
    const error = new Error("Invalid file id");
    error.status = 400;
    return next(error);
  }
  try{
    let file = await File.findById(idFile);
    let filePath = './uploads/'+file.filename;
    try {
      res.download(filePath);
    } catch {
      const error = new Error("Download failed");
      error.status = 417;
      next(error);
    }
  }
  catch {
    const error = new Error("File doesn't exist test");
    error.status = 404;
    next(error);
  }
  
})

module.exports = router