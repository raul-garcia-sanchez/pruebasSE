const express = require('express')
const auth = require('../auth/auth')
const File = require('../model/modelFile')

const router = express.Router();

router.use(auth.authenticateToken);
router.use(auth.refreshToken);

router.get("/user", async (req, res) => {

    let filesUser = [];
    let enterinFilter = false;
    for (let i = 0; i < req.user.files.length; i++) {
      let exist = await File.findById(req.user.files[i])
      if (exist) {
        filesUser.push(exist);
      }
    }

    var urlFiles = req.originalUrl;
    var nameToSearch = urlFiles.split("=")[1];
    var arrayFileFilter = [];

    if(nameToSearch){
      for(let i = 0; i < filesUser.length; i++){
        if(filesUser[i].name.includes(nameToSearch)){
          arrayFileFilter.push(filesUser[i])
        }
        enterinFilter = true;
      }
    }
    

    arrayToUse = filesUser;
    if(arrayFileFilter.length !== 0){
      arrayToUse = arrayFileFilter;
    }
    else if (enterinFilter){
      arrayToUse = [];
    }
    
    
    res.render('user.ejs', {
      user: {
        email: req.user.email,
        files: arrayToUse
      }
    })
  })

module.exports = router