# EASY CLOUD
Simple cloud for uploading and/or sharing files

## TASKS
Tasks are defined in main, solutions in the solutions branch.
Create your own branch from main and work from there.