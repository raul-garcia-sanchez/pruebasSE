const express = require('express')
const auth = require('../auth/auth')
const File = require('../model/modelFile')
const User = require('../model/modelUser')

const router = express.Router();

router.use(auth.authenticateToken);
router.use(auth.refreshToken);

router.get("/user", async (req, res,next) => {
	
	const idUser = auth.decodedJwt(req.cookies.jwt);

	const getUser = await User.findOne({_id: idUser});

	let userFiles = [];
	let page=req.query.page;
	let filter = req.query.filter;
	
	if(page==null){
		page=1;
	}

	if(filter==null){
		filter = "";
	}
	
	let long = Math.ceil(await File.count({_id:{$in:getUser.files},name:{$regex:filter}})/9);
	console.log(long);
	let filesCurrentUser = await File.find({_id:{$in:getUser.files},name:{$regex: filter}}).skip((page-1)*9).limit(9);
	
	for(let i = 0;i<filesCurrentUser.length;i++){
		userFiles.push({
			filename:filesCurrentUser[i]['filename'],
            description:filesCurrentUser[i]['description'],
            isPrivate:filesCurrentUser[i]['isPrivate'],
            name:filesCurrentUser[i]['name']
		})
	}
	
		res.render('user.ejs', {
			user: {
				email: req.user.email,
				files: userFiles,
				pages: long,
				pageUser: page,
				filter: filter,
			}
		})
	
		
})

module.exports = router