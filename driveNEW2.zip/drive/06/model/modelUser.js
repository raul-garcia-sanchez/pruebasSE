const mongoose = require('mongoose')
const bcrypt = require('bcrypt')

const modelUser = new mongoose.Schema({
    email: {type: String, required: true, unique: true},
    password: {type: String, required: true},
    files: [{type: mongoose.Schema.Types.ObjectId, ref: 'file'}],
  });

modelUser.pre('save', async function(next){
const user = this;
try{
    user.password = await bcrypt.hash(user.password,10);
    next();
}
catch(error){
    next(error)
}
});

modelUser.methods.isPassWordCorrect = function(password){
    const user = this
    const compare = bcrypt.compare(password,user.password)
    return compare
}

const User = mongoose.model('user',modelUser);
module.exports = User
