const express = require('express')
const auth = require('../auth/auth')
const multer = require("multer");
const File = require('../model/modelFile')

const multerStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./uploads");
  },
  filename: (req, file, cb) => {
    const extension = file.mimetype.split("/")[1];
    cb(null, `${file.fieldname}-${Date.now()}.${extension}`);
  },
});

const upload = multer({ storage: multerStorage });

const router = express.Router();

router.use(auth.authenticateToken);
router.use(auth.refreshToken);

router.post("/user", async (req, res) => {

  let filesUser = [];
  for (let i = 0; i < req.user.files.length; i++) {
    let exist = await File.findById(req.user.files[i])
    if (exist) {
      filesUser.push(exist);
    }
  }

  res.render('temp.ejs', {
    user: {
      email: req.user.email,
      files: filesUser
    }
  })
})

router.post("/upload", upload.single('file'), async (req, res, next) => {

  isPrivate = false;
  if (req.body.isPublic !== undefined) {
    isPrivate = true
  }

  try {
    const newFile = await File.create({ filename: req.file.filename, isPrivate: isPrivate });
    req.user.files.push(newFile);
    req.user.save();
    res.statusCode = 204;
    next();
  }
  catch (error) {
    res.statusCode = 404;
    next(error);
  }
})

router.get("/download:id", async (req, res, next) =>{
  let idFile = req.params.id.substring(1);
  if (idFile.length > 24){
    const error = new Error("Invalid file id");
    error.status = 400;
    return next(error);
  }
  try{
    let file = await File.findById(idFile);
    let filePath = './uploads/'+file.filename;
    try {
      res.download(filePath);
    } catch {
      const error = new Error("Download failed");
      error.status = 417;
      next(error);
    }
  }
  catch {
    const error = new Error("File doesn't exist test");
    error.status = 404;
    next(error);
  }
  
})

module.exports = router