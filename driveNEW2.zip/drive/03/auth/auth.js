const User = require('../model/modelUser.js')
const bcrypt = require('bcrypt')

async function signUpMiddleware(req,res,next){
    const user = {
        email: req.body.email,
        password: req.body.password
    }

    if (!user.email){
        const error = new Error('Email is required')
        error.status=400
        return next(error)
    }
    else if (!user.password){
        const error = new Error('Password is required')
        error.status = 400
        return next(error)
    }

    const userinBD = await User.findOne({ email: user.email})
    if (userinBD){
        const error = new Error("User already exists")
        error.status = 401
        return next(error)
    }
    
    const addUser = await User.create({email: user.email, password: user.password})
    next()
}


async function loginMiddleware(req,res,next){
    const user = {
        email: req.body.email,
        password: req.body.password
    }

    if (!user.email){
        const error = new Error('Email is required')
        error.status=400
        return next(error)
    }

    else if (!user.password){
        const error = new Error("Password is required")
        error.status = 400
        return next(error)
    }

    const userExists = await User.findOne({email: user.email})

    if (!userExists){
        const error = new Error("User doesn't exist")
        error.status = 400
        return next(error)
    }

    const passwordCorrect = await userExists.isPassWordCorrect(user.password)

    if (!passwordCorrect){
        const error = new Error("Incorrect password")
        error.status = 400
        return next(error)
    }
    next();
}

module.exports = {signUpMiddleware, loginMiddleware}