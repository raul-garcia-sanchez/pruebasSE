const mongoose = require('mongoose')
const argon2 = require('argon2');

const modelUser = new mongoose.Schema({
    email: {type: String, required: true, unique: true},
    password: {type: String, required: true},
    files: [{type: mongoose.Schema.Types.ObjectId, ref: 'file'}],
  });

modelUser.pre('save', async function(next){
const user = this;
try{
    const hash = await argon2.hash(user.password);
    user.password = hash
    next();
}
catch(error){
    next(error)
}
});

modelUser.methods.isPassWord = async function(password){
    const user = this
    const compare = argon2.verify(user.password,password)
    return compare
}

const User = mongoose.model('user',modelUser);
module.exports = User
