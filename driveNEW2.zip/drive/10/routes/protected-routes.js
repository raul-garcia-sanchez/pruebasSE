const express = require('express')
const auth = require('../auth/auth')
const multer = require("multer");
const File = require('../model/modelFile');
const User = require('../model/modelUser');
const fs=require('fs');

const multerStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./uploads");
  },
  filename: (req, file, cb) => {
    const extension = file.mimetype.split("/")[1];
    cb(null, `${file.fieldname}-${Date.now()}.${extension}`);
  },
});


const upload = multer({ storage: multerStorage });

const router = express.Router();
router.use(auth.authenticateToken);
router.use(auth.refreshToken);

router.post("/upload", upload.single('file'), async (req, res, next) => {
  try {
    if (req.body.description.length > 0){
      var newFile = await File.create({ filename: req.file.filename, name: req.body.name, description: req.body.description, isPrivate: req.body.isPrivate });
    }
    else{
      var newFile = await File.create({ filename: req.file.filename, name: req.body.name, isPrivate: req.body.isPrivate });
    }
    req.user.files.push(newFile);
    req.user.save();
    res.statusCode = 204;
    res.end();
  }
  catch (error) {
    res.statusCode = 404;
    next(error);
  }
});

router.post("/update", async (req,res,next) => {
  try{
    if(typeof req.body.name !== 'undefined'){
      await File.updateOne({filename:req.body.filename}, { name: req.body.name })
  }

  if(typeof req.body.description !== 'undefined'){
      await File.updateOne({filename:req.body.filename}, { description: req.body.description })
  }

  await File.updateOne({filename:req.body.filename}, { isPrivate: req.body.isPrivate })
  res.statusCode = 204;
  res.send();
  }
  catch(error){
    res.statusCode = 404;
    next(error);
  }

});

router.post("/delete", async (req,res,next) => {
  console.log(req.body.filename);
  try{
    let idUser = auth.decodedJwt(req.cookies.jwt);
    const fileToDelete = await File.findOne({filename: req.body.filename});
    await User.findOneAndUpdate({_id: idUser}, {$pull: {files: fileToDelete._id}})
    fileToDelete.delete();
    fs.unlinkSync("./uploads/"+req.body.filename);
    res.statusCode = 204
    res.send();
  }
  catch(error){
    res.statusCode = 404;
    next(error);
  }

})

router.get("/download:id", async (req, res, next) =>{
  let idFile = req.params.id.substring(1);
  if (idFile.length > 24){
    const error = new Error("Invalid file id");
    error.status = 400;
    return next(error);
  }
  try{
    let file = await File.findById(idFile);
    console.log(file.name);
    let filePath = './uploads/'+file.filename;
    try {
      res.download(filePath);
    } catch {
      const error = new Error("Download failed");
      error.status = 417;
      next(error);
    }
  }
  catch {
    const error = new Error("File doesn't exist test");
    error.status = 404;
    next(error);
  }
  
})



module.exports = router