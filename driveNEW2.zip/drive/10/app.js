const express = require('express')
const bodyParser = require('body-parser')
const mongoose = require('mongoose')
const cookieParser = require('cookie-parser');
const path = require('path')

const authRoutes = require('./routes/auth-routes.js');
const routesProtected = require('./routes/protected-routes.js');
const authViews = require('./routes/auth-views.js');
const routesProtectedViews = require('./routes/protected-views.js');

mongoose.connect("mongodb://localhost:27017/usuarios");
const port = 3000

const app = express()

app.set('view engine', 'ejs')
app.use(cookieParser())
app.use('/css', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/css')))
app.use('/js', express.static(path.join(__dirname, 'node_modules/bootstrap/dist/js')))
app.use('/jquery', express.static(path.join(__dirname, 'node_modules/jquery/dist')))


app.use(bodyParser.json());

app.use(function (req, res, next) {
  console.log(req.originalUrl);
  console.log(req.body);
  next();
})

app.use('/auth/api', authRoutes);
app.use('/auth', authViews);
app.use('/api', routesProtected);
app.use('/',routesProtectedViews);





app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})