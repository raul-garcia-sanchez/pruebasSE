const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const port = 3000

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(bodyParser.text({ type: 'text/html' }))


app.use(function (req, res) {
    console.log(req.originalUrl);
    console.log(req.body);
    res.statusCode = 501;
    res.end();
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})