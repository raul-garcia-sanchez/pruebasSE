const mongoose = require('mongoose');

const fileSchema = new mongoose.Schema({
    filename: {type: String, required: true, unique: true},
    name:{type:String, required: true},
    description:{type: String},
    isPrivate: {type: Boolean, default: true}
})

const File = mongoose.model('file', fileSchema)
module.exports = File