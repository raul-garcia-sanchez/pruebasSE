const express = require('express')
const auth = require('../auth/auth')
const File = require('../model/modelFile')

const router = express.Router();

router.use(auth.authenticateToken);
router.use(auth.refreshToken);
var started = 0;
var finished = 0;
router.get("/user", async (req, res) => {

    let filesUser = [];
    let enterinFilter = false;
    for (let i = 0; i < req.user.files.length; i++) {
      let exist = await File.findById(req.user.files[i])
      if (exist) {
        filesUser.push(exist);
      }
    }
 
    var nameToSearch = req.query.filter;
    var arrayFileFilter = [];

    if(nameToSearch){
      for(let i = 0; i < filesUser.length; i++){
        if(filesUser[i].name.includes(nameToSearch)){
          arrayFileFilter.push(filesUser[i])
        }
        enterinFilter = true;
      }
    }
    
    arrayToUse = filesUser;
    if(arrayFileFilter.length !== 0){
      arrayToUse = arrayFileFilter;
    }

  
    else if (enterinFilter){
      arrayToUse = [];
    }
    

    let userpages = Math.round((arrayToUse.length/9)+1);
    console.log(userpages);

    

    if(req.query.page > userpages){
      arrayToUse = [];
    }

    if(!req.query.page){
       started = 0;
       finished = 9;
    }
    else{
       if (Number(req.query.page) > 1){
         started = started + 9;
         finished = started + 9;
      }
      else{
         started = (req.query.page)-1;
         finished = Number((req.query.page))+8;
      }
    }
    //console.log(started);
    //console.log(finished);
    
   
    res.render('user.ejs', {
      user: {
        email: req.user.email,
        files: arrayToUse.slice(started,finished),
        pages: userpages,
        page: Number(req.query.page),
        filter: Number(req.query.filter),
        maxFilesPage: userpages//quitar
      }
    })
  })

module.exports = router