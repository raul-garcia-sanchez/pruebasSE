const express = require('express')
const auth = require('../auth/auth')
const File = require('../model/modelFile')

const router = express.Router();

router.use(auth.authenticateToken);
router.use(auth.refreshToken);

router.get("/user", async (req, res) => {

    let filesUser = [];
    for (let i = 0; i < req.user.files.length; i++) {
      let exist = await File.findById(req.user.files[i])
      if (exist) {
        filesUser.push(exist);
      }
    }
  
    res.render('temp.ejs', {
      user: {
        email: req.user.email,
        files: filesUser
      }
    })
  })

module.exports = router