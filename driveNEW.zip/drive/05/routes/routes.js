const express = require('express')
const jwt = require('jsonwebtoken');
const auth = require('../auth/auth');

const router = express.Router();

router.post("/signup", auth.signUpMiddleware, (req, res) => {
    res.statusCode = 204;
    res.end();
})

router.post("/login", auth.loginMiddleware, (req, res) => {
    const token = jwt.sign({exp: Math.floor(Date.now() / 1000) + (60 * 60),data: req.user._id}, 'secreto-de-test');
    res.cookie('jwt',token,{httpOnly: true});
    res.end();
})

module.exports = router