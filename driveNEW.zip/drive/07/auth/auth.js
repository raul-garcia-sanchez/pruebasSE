const express = require('express')
const jwt = require('jsonwebtoken');
const User = require('../model/modelUser.js')
const bcrypt = require('bcrypt')
const cookieParser = require('cookie-parser')

const app = express();
app.use(cookieParser());

function refreshToken(req,res,next){
    try{
        const token = jwt.sign({exp: Math.floor(Date.now() / 1000) + (60 * 60),data: req.user._id}, 'secreto-de-test');
        res.cookie('jwt',token,{httpOnly: true});
        next();
    }
    catch(error){
        next(error);
    }
}

async function authenticateToken(req,res,next){
    try{
        const token = req.cookies.jwt;
        const decoded = jwt.verify(token,"secreto-de-test");
        const user = await User.findOne({_id:decoded.data});
        if (!user){
            const error = new Error("User doesn't exist");
            return next(error);
        }
        req.user = user
        next();
    }
    catch(error){
        error.status = 401;
        next(error);
    }
}

async function signUpMiddleware(req,res,next){
    const user = {
        email: req.body.email,
        password: req.body.password
    }

    if (!user.email){
        const error = new Error('Email is required')
        error.status=400
        return next(error)
    }
    else if (!user.password){
        const error = new Error('Password is required')
        error.status = 400
        return next(error)
    }

    const userinBD = await User.findOne({ email: user.email})
    if (userinBD){
        const error = new Error("User already exists")
        error.status = 401
        return next(error)
    }
    
    const addUser = await User.create({email: user.email, password: user.password});
    next();
}

async function loginMiddleware(req,res,next){
    const user = {
        email: req.body.email,
        password: req.body.password
    }

    if (!user.email){
        const error = new Error('Email is required')
        error.status=400
        return next(error)
    }

    else if (!user.password){
        const error = new Error("Password is required")
        error.status = 400
        return next(error)
    }

    const userExists = await User.findOne({email: user.email})

    if (!userExists){
        const error = new Error("User doesn't exist")
        error.status = 400
        return next(error)
    }

    const passwordCorrect = await userExists.isPassWordCorrect(user.password)

    if (!passwordCorrect){
        const error = new Error("Incorrect password")
        error.status = 400
        return next(error)
    }

    req.user = userExists;
    next();
    
}

module.exports = {signUpMiddleware, loginMiddleware, authenticateToken, refreshToken}