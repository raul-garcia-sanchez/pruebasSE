const express = require('express')
const auth = require('../auth/auth')

const router = express.Router();

router.post("/signup", auth.signUpMiddleware, (req, res) => {
    res.statusCode = 204;
    res.end();
})

router.post("/login", auth.loginMiddleware, (req, res) => {
    res.statusCode = 204;
    res.end();
})

module.exports = router





