const express = require('express')
const auth = require('../auth/auth')
const File = require('../model/modelFile')
const User = require('../model/modelUser')

const router = express.Router();

router.use(auth.authenticateToken);
router.use(auth.refreshToken);

router.get("/user", async (req, res,next) => {
	
	const idUser = auth.decodedJwt(req.cookies.token);

	const getUser = await User.findOne({_id: idUser});

	let userFiles = [];
	let page=req.query.page;
	let filter = req.query.filter;
	
	if(filter==null){
		filter = "";
	}

	let sizeFiles = Math.ceil(await File.count({_id:{$in:getUser.files},name:{$regex:filter}})/9);
	console.log(sizeFiles);

	
	if(Number(page) > sizeFiles){
		//req.originalUrl = req.originalUrl.replace(Number(page),sizeFiles);
		res.redirect("/user?page="+sizeFiles);
		page=sizeFiles;
		
		//console.log("me deberia redireccionar a la pag mas grande que tengo");
	}
	else if(Number(page) < 1){
		res.redirect("/user?page=1");
		page=1;
	}
	
	let filesCurrentUser = await File.find({_id:{$in:getUser.files},name:{$regex: filter}}).skip((page-1)*9).limit(9);
	
	for(let i = 0;i<filesCurrentUser.length;i++){
		userFiles.push({
			filename:filesCurrentUser[i]['filename'],
            description:filesCurrentUser[i]['description'],
            isPrivate:filesCurrentUser[i]['isPrivate'],
            name:filesCurrentUser[i]['name']
		})
	}

	
	res.render('user.ejs', {
		user: {
			email: req.user.email,
			files: userFiles,
			pages: sizeFiles,
			pageUser: page,
			filter: filter,
		}
	})
	
})

module.exports = router
/*
<% if(user.pages && user.pages>=1){%>
	<%if((user.pages-5)>=1) {%>
		<li class="page-item"><a class="page-link" href="/user?page=1"> <<< </a></li>
	<%}%>
	<%let count=1 %>
	<%if((user.pageUser-4)>0) {%>
		<% count=user.pageUser-4 %>
	<%}%>
	<%for (i=0; user.pages>=count; count++){%>
		<%if(count == user.pageUser){%>
			<li class="page-item active"><a class="page-link" ><%=count%></a></li>
		<%} else{%>
			<li class="page-item"><a class="page-link" href="/user?page=<%=count%>"><%=count%></a></li>
		<%}%>
	<%}%>
	<%if(user.pages > 5){%>
		<li class="page-item"><a class="page-link" href="/user?page=<%=user.pages%>"> >>> </a></li>
	<%}%>
<%}%>
*/