const express = require('express');
const jwt = require('jsonwebtoken');

const auth = require('../auth/auth');

const router = express.Router();

router.post("/signup", auth.signUpMiddleware, (req, res) => {
    res.status(204).send();
});

router.post("/login", auth.loginMiddleware, (req, res) => {
    console.log("User:"+req.user);
    const token = jwt.sign({exp: Math.floor(Date.now() / 1000) + (60 * 60),data: req.user._id}, 'secreto-de-test');
    res.setHeader('Set-Cookie', `token=${token}; Path=/; HttpOnly`);
    res.status(204).send();
});

module.exports = router